
package pokemon;


public class Encostipat implements Capturable {

    @Override
    public boolean Capturar() {
        throw new UnsupportedOperationException("Not supported yet.");
    }
    
    
    
}
